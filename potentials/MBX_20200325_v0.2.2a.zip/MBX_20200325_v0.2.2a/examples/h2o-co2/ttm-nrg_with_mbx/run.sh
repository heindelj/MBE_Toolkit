#!/bin/bash

../../../install/bin/main/single_point input.nrg mbx.json
