#define CATCH_CONFIG_MAIN

#include "Catch2/single_include/catch.hpp"
