#!/bin/bash 

../../../../install/bin/n_single_point 512w.nrg 30
../../../../install/bin/n_single_point 512w.nrg 30 mbx.json
