#!/bin/bash 

../../../../install/bin/n_single_point 256w.nrg 30 256w_mbx.json
