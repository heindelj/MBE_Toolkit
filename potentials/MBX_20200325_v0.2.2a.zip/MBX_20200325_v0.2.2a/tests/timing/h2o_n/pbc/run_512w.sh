#!/bin/bash 

../../../../install/bin/n_single_point 512w.nrg 30 512w_mbx.json
